/**
 * @file YourAddonName.cpp
 * @author 
 *
 * @brief 
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#include "YourAddonName.h"

DLVHEX_NAMESPACE_BEGIN
YourAddonName::Environment::Environment() {
	// Initialize here your Environment
}

YourAddonName::Environment::~Environment() {
	// Frees the memory allocated dynamically
}

YourAddonName::YourExternalAtom::YourExternalAtom() :
		PluginActionAtom("nameOfYourExternalAtom") {
		
	// Specify here Input and Output arity
	
}

void YourAddonName::YourExternalAtom::retrieve(
		const Environment& environment, const Query& query, Answer& answer) {

	// Get Registry
	// *getRegistry();
	
	// Get Input elements
	// query.input
	
	// Do your stuff
	
	// Create the output Tuple(s)
	// Tuple
	
	// Create Term(s)
	// Term
	
	// Store Term(s) in the Registry and push in the Tuple
	// tuple.push_back(registry.storeTerm(term));
	
	// Push the Tuple in the Answer
	// answer.get().push_back(out);
	
}

YourAddonName::YourActionAtom::YourActionAtom() :
		PluginAction("nameOfYourActionAtom") {
}

void YourAddonName::YourActionAtom::execute(Environment& environment,
		RegistryPtr pregistry, const Tuple& parms,
		const InterpretationConstPtr interpretationPtr) {

	// Do your stuff

}

std::vector<PluginAtomPtr> YourAddonName::createAtoms(ProgramCtx& ctx) const {
	
	// Push in a vector of PluginAtomPtr all the External Atoms and return it
	
	std::vector<PluginAtomPtr> ret;
	ret.push_back(PluginAtomPtr(new YourExternalAtom,
					PluginPtrDeleter<PluginAtom>()));
	return ret;
	
}

std::vector<PluginActionBasePtr> YourAddonName::createActions(ProgramCtx& ctx) const {
	
	// Push in a vector of PluginAtomPtr all the Action Atoms and return it
	
	std::vector<PluginActionBasePtr> ret;
	ret.push_back(PluginActionBasePtr(new YourActionAtom,
					PluginPtrDeleter<PluginActionBase>()));
	return ret;
	
}

//
// now instantiate the plugin
//
YourAddonName theYourAddonName;

DLVHEX_NAMESPACE_END

//
// let it be loaded by dlvhex!
//
IMPLEMENT_PLUGINABIVERSIONFUNCTION

// return plain C type s.t. all compilers and linkers will like this code
extern "C" void * PLUGINIMPORTFUNCTION() {
return reinterpret_cast<void*>(& DLVHEX_NAMESPACE theYourAddonName);
}
