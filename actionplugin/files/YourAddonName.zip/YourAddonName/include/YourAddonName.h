/**
 * @file YourAddonName.h
 * @author 
 *
 * @brief 
 */

#ifndef YOUR_ADDON_NAME_H_
#define YOUR_ADDON_NAME_H_

#include "acthex/ActionPluginInterface.h"

DLVHEX_NAMESPACE_BEGIN

class YourAddonName: public ActionPluginInterface {

public:

	YourAddonName() :
			ActionPluginInterface() {
		setNameVersion(PACKAGE_TARNAME, YOURADDONNAME_VERSION_MAJOR,
						YOURADDONNAME_VERSION_MINOR, YOURADDONNAME_VERSION_MICRO);
	}

	/**
	 * @brief Environment
	 */
	class Environment: public PluginEnvironment {
	public:
		Environment();
		virtual ~Environment();
		// Put here your code
	};

	/**
	 * @brief Implement a class that extends PluginActionAtom (like this) to specify an External Atom
	 */
	class YourExternalAtom: public PluginActionAtom<YourAddonName> {
	public:
		YourExternalAtom();
	private:
		// You need to override this method to specify the behaviour of the External Atom
		virtual void retrieve(const Environment& environment, const Query& query, Answer& answer);
	};

	/**
	 * @brief Implement a class that extends PluginAction (like this) to specify an Action Atom
	 */
	class YourActionAtom: public PluginAction<YourAddonName> {
	public:
		YourActionAtom();
	private:
		// You need to override this method to specify the behaviour of the Action Atom
		virtual void execute(Environment&, RegistryPtr, const Tuple&, const InterpretationConstPtr);
	};

	/**
	 * @brief Implement this method to specify which External Atoms you want to use
	 */
	virtual std::vector<PluginAtomPtr> createAtoms(ProgramCtx& ctx) const;

	/**
	 * @brief Implement this method to specify which Action Atoms you want to use
	 */
	virtual std::vector<PluginActionBasePtr> createActions(ProgramCtx& ctx) const;

protected:

	/**
	 * @brief A method to have the correct Environment
	 */
	ActionPluginInterfacePtr create(ProgramCtx& ctx) {
		ctx.getPluginEnvironment<YourAddonName>();
		return boost::shared_ptr <YourAddonName> (new YourAddonName());
	}

};

DLVHEX_NAMESPACE_END

#endif /* YOUR_ADDON_NAME_H_ */
