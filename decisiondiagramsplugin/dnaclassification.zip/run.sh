# convert input classifiers
echo "Converting RapidMiner's input decision trees into HEX programs"
i=1;
for t in $(ls model*.xml 2> /dev/null)
do
	echo "Converting $t into ${t/.xml/.hex}"
	graphconverter rmxml hex < $t > ${t/.xml/.hex}
done

# create merging plan
cs=$(echo -e "[common signature]\n
predicate: root/1;\n
predicate: innernode/1;\n
predicate: leafnode/2;\n
predicate: conditionaledge/5;\n
predicate: elseedge/2;\n
")
i=1;
for t in $(ls model*.xml 2> /dev/null)
do
	# belief base section
	bb=$(echo -e $bb "[belief base] name: kb$i;\nsource: \"${t/.xml/.hex}\";")

	# merging plan
	if [ $i -eq 1 ]; then
		mp=$(echo -e "kb$i")
	else
		mp=$(echo -e "operator: distributionmapvoting;\n{\n$mp\n};\n{kb$i};")
	fi
	i=$(expr $i + 1)
done
mp=$(echo -e "[merging plan]{\n$mp\n}")

echo "Writing merging plan"
echo -e $cs $bb $mp > salzbergoperator.mp

# execute merging plan
echo "Executing merging plan"
dlvhex --merging --silent salzbergoperator.mp > merged_model.as

# convert result
echo "Converting output decision tree into RapidMiner format"
graphconverter as rmxml < merged_model.as > merged_model.xml
